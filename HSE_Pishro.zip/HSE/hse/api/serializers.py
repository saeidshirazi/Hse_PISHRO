from .models import *
from rest_framework import serializers
import datetime
from django.contrib.auth.models import User






#####################
# User Serializer
#####################

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id','username',)

#####################
# change password Serializer
#####################

class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    
#####################
# register Serializer
#####################
class RegistrationSerializer (serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    def create(self, validated_data):
        user = User.objects.create(
            username = validated_data['username']
        )
        user.set_password(validated_data['password'])
        user.save()
        return user
    class Meta:
        model = User
        fields = ('username','password')


#####################
# profile Serializer
#####################
class ProfileSerializer(serializers.ModelSerializer):   
    class Meta:
        model=Profile
        fields = ("__all__")
        read_only_fields = ('owner',)


#####################
# workstation Serializer
#####################
class WorkStationSerializer(serializers.ModelSerializer):   
    class Meta:
        model=WorkStation
        fields = ("__all__")

#####################
# worksection Serializer
#####################
class WorkSectionSerializer(serializers.ModelSerializer):
    workstation_id = WorkStationSerializer(many=False, read_only=True)   
    class Meta:
        model=WorkSection
        fields = ('id','work_section','workstation_id')






#####################
# status Serializer
#####################
class StatusSerializer(serializers.ModelSerializer):   
    class Meta:
        model=Status
        fields = ('id','status_name')

#####################
# Report Type Serializer
#####################
class ReportTypeSerializer(serializers.ModelSerializer):   
    class Meta:
        model=ReportType
        fields = ("__all__")


#####################
# Report Audio Serializer
#####################
class ReportAudioSerializer(serializers.ModelSerializer):
    owner = UserSerializer(many=False, read_only=True)
    class Meta:
        model=ReportAudio
        fields = ("__all__")
        read_only_fields = ('owner',)




#####################
# Report Video Serializer
#####################
class ReportVideoSerializer(serializers.ModelSerializer):
    owner = UserSerializer(many=False, read_only=True)
    class Meta:
        model=ReportVideo
        fields = ("__all__")
        read_only_fields = ('owner',)

#####################
# Report Image Serializer
#####################
class ReportImageSerializer(serializers.ModelSerializer):
    owner = UserSerializer(many=False, read_only=True)
    class Meta:
        model=ReportImage
        fields = ("__all__")
        read_only_fields = ('owner',)

#####################
# Report Recently Serializer
#####################
class RecentlyReportSerializer(serializers.ModelSerializer):
    location = WorkSectionSerializer(many=False, read_only=True)
    class Meta:
        model=Report
        fields = ('id','location')

#####################
# Report Details Serializer
#####################
class ReportDetailsSerializer(serializers.ModelSerializer):
    owner = UserSerializer(many=False, read_only=True)
    location = WorkSectionSerializer(many=False, read_only=True)
    status = StatusSerializer(many=False, read_only=True)
    report_type = ReportTypeSerializer(many=False, read_only=True)
    class Meta:
        model=Report
        fields = ('id','created','updated_at','owner','location_map','location','status',
                'description','get_time_diff','report_type')

        read_only_fields = ('owner',)


#####################
# Report  Serializer
#####################
class ReportSerializer(serializers.ModelSerializer):    
    class Meta:
        model=Report
        fields = ('id','created','updated_at','location_map','location','status',
                'description','report_type')

        read_only_fields = ('owner',)

    
#####################
# Favorite Serializer
#####################
class FavoriteSerializer(serializers.ModelSerializer):
    class Meta:
        model=Favorite
        fields = ("__all__")
        read_only_fields = ('owner',)


#####################
# Favorite Details Serializer
#####################
class FavoriteDetailsSerializer(serializers.ModelSerializer):
    location = WorkSectionSerializer(many=False, read_only=True)
    class Meta:
        model=Favorite
        fields = ('id','location')                 

#####################
# contactus Serializer
#####################
class ContactUsSerializer(serializers.ModelSerializer):
    class Meta:
        model=ContactUs
        fields = ("__all__")

#####################
# EMGCALL Serializer
#####################
class EMGCALLUsSerializer(serializers.ModelSerializer):
    class Meta:
        model=EMGCALL
        fields = ("__all__")


#####################
# Update Serializer
#####################
class UpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model=Update
        fields = ('version','url')                   


#####################
# Icon Serializer
#####################
class IconSerializer(serializers.ModelSerializer):
    class Meta:
        model=Icon
        fields = ('Icon_name','Icon_pic')   