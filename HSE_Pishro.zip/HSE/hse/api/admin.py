# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib import admin
from .models import *
from import_export import resources
from import_export.admin import ExportActionMixin
from django.utils.html import format_html
from django.utils.safestring import mark_safe






admin.site.site_header = "ESATA Admin"
admin.site.site_title = "HSE ESATA Admin Portal"
admin.site.site_url = "/api"

########################################################

class ReportAudioInline(admin.TabularInline):
    model = ReportAudio 
class ReportVideoInline(admin.TabularInline):
    model = ReportVideo 
class ReportImageInline(admin.TabularInline):
    model = ReportImage
class ReportImageAdmin(admin.ModelAdmin):
    def image_tag(self, obj):
        return mark_safe('<img src="{}" height="150" width="150" />'.format(obj.image.url))

    image_tag.short_description = 'Image'
    list_display = ['owner','report','created','image_tag',]
    list_filter=('owner', 'report')


class ReportAdmin(ExportActionMixin,admin.ModelAdmin):

        list_display=( 'owner','location','report_type', 'created')
        list_filter=('status', 'owner', 'location','report_type')
        ordering=['-created', '-updated_at']
        inlines = [ReportImageInline,ReportAudioInline,ReportVideoInline]


##########################################################
class FavoriteAdmin(ExportActionMixin,admin.ModelAdmin,):
        list_display=('location', 'owner', 'created')
        list_filter=('owner', 'location')
        ordering=['-created', '-updated_at']

class ProfileAdmin(ExportActionMixin,admin.ModelAdmin):
        class Meta:
                model=Profile
                fields=("__all__")


################################################################




myModels=[WorkSection,WorkStation,Status,
          ContactUs,EMGCALL,ReportVideo,
          ReportAudio,ReportType,Update,Icon]

admin.site.register(ReportImage, ReportImageAdmin)
admin.site.register(Profile, ProfileAdmin)
admin.site.register(Favorite, FavoriteAdmin)
admin.site.register(Report, ReportAdmin)
admin.site.register(myModels)