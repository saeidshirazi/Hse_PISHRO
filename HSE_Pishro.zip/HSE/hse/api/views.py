# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from rest_framework.response import Response
from .models import *
from rest_framework import viewsets,permissions,status,mixins,generics
from rest_framework.views import exception_handler,APIView
from .serializers import *
from rest_framework.exceptions import APIException
import django_filters
from django_filters import rest_framework as filters
import django_filters.rest_framework
from .filters import *
from rest_framework.decorators import action
from rest_framework.filters import SearchFilter, OrderingFilter
from django.contrib.auth import authenticate
from django.views.decorators.csrf import csrf_exempt
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny,IsAuthenticated
from rest_framework.status import (
    HTTP_400_BAD_REQUEST,
    HTTP_404_NOT_FOUND,
    HTTP_204_NO_CONTENT,
    HTTP_200_OK
)
from rest_framework.response import Response
from rest_framework.generics import RetrieveUpdateDestroyAPIView,CreateAPIView,ListCreateAPIView
from django.views.decorators.http import require_http_methods,require_GET





#####################
# Change pass View
#####################

class ChangePasswordView(mixins.UpdateModelMixin,
                         viewsets.GenericViewSet):
        """
        An endpoint for changing password.
        """
        serializer_class = ChangePasswordSerializer
        model = User
        permission_classes = (IsAuthenticated,)

        def get_object(self, queryset=None):
            obj = self.request.user
            return obj

        def update(self, request, *args, **kwargs):
            self.object = self.get_object()
            serializer = self.get_serializer(data=request.data)

            if serializer.is_valid():
                # Check old password
                if not self.object.check_password(serializer.data.get("old_password")):
                    return Response({"old_password": ["Wrong password."]}, status=status.HTTP_400_BAD_REQUEST)
                # set_password also hashes the password that the user will get
                self.object.set_password(serializer.data.get("new_password"))
                self.object.save()
                return Response("Success.", status=status.HTTP_200_OK)

            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#####################
# logout View
#####################

class Logout(APIView):
    def get(self, request, format=None):        
        request.user.auth_token.delete()
        content = {'logout succesfully'}
        return Response(content,status=status.HTTP_200_OK)

#####################
# Register View
#####################
class RegistrationView(CreateAPIView):
    model = User
    serializer_class = RegistrationSerializer
    permission_classes = (permissions.AllowAny,)
    



#####################
# profile View
#####################

class ProfileViewSet(viewsets.ModelViewSet):
    queryset = Profile.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = ProfileSerializer
    def get_queryset(self):
        user = self.request.user.id
        return Profile.objects.filter(owner=user)   





#####################
# workstation View
#####################


class WorkStationViewSet(viewsets.ModelViewSet):
    queryset = WorkStation.objects.all()
    permission_classes = [permissions.AllowAny, ]
    serializer_class = WorkStationSerializer
    http_method_names = ['get',]
    filter_backends = (filters.DjangoFilterBackend, SearchFilter, OrderingFilter)
    filter_class = WorkStationFilter    
    search_fields = ['work_station', ]



#####################
# worksection View
#####################

class WorkSectionViewSet(viewsets.ModelViewSet):
    queryset = WorkSection.objects.all()
    permission_classes = [permissions.AllowAny, ]
    serializer_class = WorkSectionSerializer
    http_method_names = ['get',]
    filter_backends = (filters.DjangoFilterBackend, SearchFilter, OrderingFilter)
    filter_class = WorkSectionFilter    
    search_fields = ['work_section', ]


#####################
# Status View
#####################

class StatusViewSet(viewsets.ModelViewSet):
    queryset = Status.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = StatusSerializer
    http_method_names = ['get',]


#####################
# Report Type View
#####################

class ReportTypeViewSet(viewsets.ModelViewSet):
    queryset = ReportType.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = ReportTypeSerializer
    http_method_names = ['get',]    



#####################
# Report Audio View
#####################

class ReportAudioViewSet(viewsets.ModelViewSet):
    queryset = ReportAudio.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = ReportAudioSerializer
    filter_backends = (filters.DjangoFilterBackend,)
    filter_class = ReportAudioFilter

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)

    def get_queryset(self):
        user = self.request.user.id
        return ReportAudio.objects.filter(owner=user)
#####################
# Report Video View
#####################

class ReportVideoViewSet(viewsets.ModelViewSet):
    queryset = ReportVideo.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = ReportVideoSerializer
    filter_backends = (filters.DjangoFilterBackend,)
    filter_class = ReportVideoFilter

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)

    def get_queryset(self):
        user = self.request.user.id
        return ReportVideo.objects.filter(owner=user)

#####################
# Report image View
#####################

class ReportImageViewSet(viewsets.ModelViewSet):
    queryset = ReportImage.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = ReportImageSerializer
    filter_backends = (filters.DjangoFilterBackend,)
    filter_class = ReportImgFilter

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)

    def get_queryset(self):
        
        user = self.request.user.id
        return ReportImage.objects.filter(owner=user)
        

#####################
# Report View
#####################

class ReportDetailsViewSet(viewsets.ModelViewSet):
    queryset = Report.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = ReportDetailsSerializer
    filter_backends = [django_filters.rest_framework.DjangoFilterBackend]
    http_method_names = ['get',]
    def get_queryset(self):
        user = self.request.user.id
        return Report.objects.filter(owner=user)    

    @action(methods=['get'], detail=False)
    def newest(self,request):
        newest = self.get_queryset().order_by("created").last()
        serializer = self.get_serializer_class()(newest)
        return Response(serializer.data)


#####################
# Report View
#####################

class ReportViewSet(viewsets.ModelViewSet):
    queryset = Report.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = ReportSerializer

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)

    def get_queryset(self):
        user = self.request.user.id
        return Report.objects.filter(owner=user)   


#####################
# Recently Report Type View
#####################

class RecentlyReportViewSet(viewsets.ModelViewSet):
    #queryset = Report.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = RecentlyReportSerializer
    http_method_names = ['get',]
    def get_queryset(self):
        user = self.request.user.id
        return  Report.objects.filter(owner = user).distinct('location_id').order_by('location_id')

       



#####################
# Favorite View
#####################

class FavoriteView(APIView):
    permission_classes = [permissions.IsAuthenticated, ]    
    def post(self, request, format=None, *args, **kwargs):        
        serializer = FavoriteSerializer(data=request.data)
        if serializer.is_valid() :
            lc=self.request.data.get('location')
            queryset = Favorite.objects.filter(owner=self.request.user,location=lc)
            if  queryset.exists():
                queryset.delete()
                content = {'unfavorite shud haha :)'}
                return Response(content,status=status.HTTP_204_NO_CONTENT)
            else:
                serializer.save(owner=self.request.user)
                content = {'favorite shud haha :)'}
                return Response(serializer.data, status=status.HTTP_201_CREATED)
                
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



#####################
# Favorite Details View
#####################
class FavoriteDetailsViewSet(viewsets.ModelViewSet):
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = FavoriteDetailsSerializer
    def get_queryset(self):
        user = self.request.user.id
        return Favorite.objects.filter(owner=user)


#####################
# CONTACTUS View
#####################

class ContactUsViewSet(viewsets.ModelViewSet):
    queryset = ContactUs.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = ContactUsSerializer
    http_method_names = ['get',]
#####################
# EMGCALL View
#####################

class EMGCALLViewSet(viewsets.ModelViewSet):
    queryset = EMGCALL.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = EMGCALLUsSerializer
    http_method_names = ['get',]


#####################
# Update View
#####################

class UpdateViewSet(viewsets.ModelViewSet):
    queryset = Update.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = UpdateSerializer
    http_method_names = ['get',]  

#####################
# Icons View
#####################

class IconsViewSet(viewsets.ModelViewSet):
    queryset = Icon.objects.all()
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class = IconSerializer
    http_method_names = ['get',]    

