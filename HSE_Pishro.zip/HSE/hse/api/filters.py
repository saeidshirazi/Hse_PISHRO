from .models import *
import django_filters
from django_filters import rest_framework as filters




#####################
# workstation filter
#####################

class WorkStationFilter(filters.FilterSet):
    
    class Meta:
        model = WorkStation
        fields = ['work_station',]


#####################
# worksection filter
#####################

class WorkSectionFilter(filters.FilterSet):
    
    class Meta:
        model = WorkSection
        fields = ['workstation_id',]



#####################
# Report Audio filter
#####################

class ReportAudioFilter(filters.FilterSet):
    
    class Meta:
        model = ReportAudio
        fields = ['report']

#####################
# Report video filter
#####################

class ReportVideoFilter(filters.FilterSet):
    
    class Meta:
        model = ReportVideo
        fields = ['report']
#####################
# Report image filter
#####################

class ReportImgFilter(filters.FilterSet):
    
    class Meta:
        model = ReportImage
        fields = ['report']
#####################
# Report filter
#####################

class ReportFilter(filters.FilterSet):
    
    class Meta:
        model = Report
        fields = ['owner', ]





###############################################################

filters.LOOKUP_TYPES = [
    ('', '---------'),
    ('exact', 'Is equal to'),
    ('not_exact', 'Is not equal to'),
    ('lt', 'Lesser than'),
    ('gt', 'Greater than'),
    ('gte', 'Greater than or equal to'),
    ('lte', 'Lesser than or equal to'),
    ('startswith', 'Starts with'),
    ('endswith', 'Ends with'),
    ('contains', 'Contains'),
    ('not_contains', 'Does not contain'),
]

