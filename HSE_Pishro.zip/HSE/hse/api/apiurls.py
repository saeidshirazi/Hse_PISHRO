from django.contrib import admin
from django.contrib.auth import views 
from django.conf.urls import url, include
from django.urls import include, path
from rest_framework import routers
from . import views
from django.conf.urls.static import static
from django.conf import settings



router = routers.DefaultRouter()

router.register(r'User', views.ChangePasswordView,base_name='change password')
router.register(r'profile', views.ProfileViewSet)
router.register(r'workstation', views.WorkStationViewSet)
router.register(r'worksection', views.WorkSectionViewSet)
router.register(r'status', views.StatusViewSet)
router.register(r'ReportType', views.ReportTypeViewSet)
router.register(r'ReportAudio', views.ReportAudioViewSet,base_name='Report_Audio')
router.register(r'ReportVideo', views.ReportVideoViewSet,base_name='Report_Videos')
router.register(r'ReportImage', views.ReportImageViewSet,base_name='Report_images')
router.register(r'ReportDetail', views.ReportDetailsViewSet,base_name='Report_details')
router.register(r'RecentlyReport', views.RecentlyReportViewSet,base_name='Recently_Report')
router.register(r'Report', views.ReportViewSet,base_name='Report')
router.register(r'FavoriteDetails', views.FavoriteDetailsViewSet,base_name='Favorite_Details')
router.register(r'Contactus', views.ContactUsViewSet)
router.register(r'EMGCALL', views.EMGCALLViewSet)
router.register(r'Checkupdate', views.UpdateViewSet)
router.register(r'Icons', views.IconsViewSet)


###################################################################
import debug_toolbar
urlpatterns = [
    url("^", include(router.urls)),
    url(r'^fv/', views.FavoriteView.as_view(),name='favorite_view'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

