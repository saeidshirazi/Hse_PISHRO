# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
from phonenumber_field.modelfields import PhoneNumberField
from model_utils import Choices
from django.utils.translation import ugettext_lazy as _
from location_field.models.plain import PlainLocationField
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils.timezone import now, localtime
from django.utils.timezone import utc
import datetime
# Create your models here.

######################
# Profile CLASS
###################### 

class Profile(models.Model):
    created=models.DateTimeField(auto_now_add=True, verbose_name=_('created'))
    updated_at=models.DateTimeField(auto_now_add=True, verbose_name=_('updated at'))
    owner = models.OneToOneField(User, related_name='profile_owner',
                            on_delete=models.CASCADE,default=1)

    name = models.CharField(max_length=100, default='', verbose_name=_('full name'))
    job_position = models.CharField(max_length=100,null=True,blank=True ,default='', verbose_name=_('job postion'))                        
    pic_profile  = models.ImageField(upload_to='media', null=True,
                   blank=True,default=None,verbose_name=_('profile picture'))
    
    class Meta:
        
        ordering = ('-created',)
        verbose_name=_('Profile')
        verbose_name_plural=_('Profiles')

    def __str__(self):
        return str(self.owner)

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(owner=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile_owner.save()        


######################
# WORKSTATION CLASS
######################  

class WorkStation(models.Model):
    created=models.DateTimeField(auto_now_add=True, verbose_name=_('created'))
    updated_at=models.DateTimeField(auto_now_add=True, verbose_name=_('updated at'))
    work_station = models.CharField(max_length=100, default='', verbose_name=_('work station'))
    class Meta:
        ordering = ('-created',)
        verbose_name=_('Work Station')
        verbose_name_plural=_('Work Stations')

    def __str__(self):
        return self.work_station

######################
# WORKSECTION CLASS
######################  

class WorkSection(models.Model):
    created=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    workstation_id = models.ForeignKey(WorkStation,
                                    on_delete=models.CASCADE,default=1,
                                    related_name='workstation_id')
 
    work_section = models.CharField(max_length=100, default='')

    class Meta:
        ordering = ('-created',)
        verbose_name=_('Work Section')
        verbose_name_plural=_('Work Sections')

    def __str__(self):
        explain='''Workstation Name is {} & Worksection Name is {}'''.format(str(self.workstation_id),str(self.work_section))
        return explain


######################
# STATUS CLASS
######################  

class Status(models.Model):
    created=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    status_name=models.CharField(max_length=100, default='')

    class Meta:
        ordering = ('created',)
        verbose_name=_('Status')
        verbose_name_plural=_('Statuses')

    def __str__(self):
        return str(self.status_name)
 

######################
# ReportType CLASS
######################  

class ReportType(models.Model):
    created=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    ReportType_Name=models.CharField(max_length=100, default='')

    class Meta:
        ordering = ('-created',)
        verbose_name=_('Report Type')
        verbose_name_plural=_('Report Types')

    def __str__(self):
        return str(self.ReportType_Name)
######################
# Report CLASS
######################  

class Report(models.Model):
    created=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    owner = models.ForeignKey(User, related_name='inc_owner',
                            on_delete=models.CASCADE,default=1)       
    location_map = PlainLocationField(based_fields=['city'], zoom=7,null=True,blank=True)
  
    location =  models.ForeignKey(WorkSection,
                                    on_delete=models.CASCADE,default=1,
                                    related_name='incident_location')

    report_type= models.ForeignKey(ReportType,
                                    on_delete=models.CASCADE,default=1,
                                    related_name='ReportTypes')
    status= models.ForeignKey(Status,
                                    on_delete=models.CASCADE,default=1,
                                    related_name='inc_status')

    description= models.TextField(null=True,default='')    
    
    
    @property
    def get_time_diff(self):
        if self.created:
            now = datetime.datetime.utcnow().replace(tzinfo=utc)
            timediff = now - self.created
            #print(timediff)
            return timediff.days

    

    class Meta:
        ordering = ('-created',)
        verbose_name=_('Report')
        verbose_name_plural=_('Reports')
    def __str__(self):
        return str(self.location)
######################
# Report IMage CLASS
###################### 
class ReportImage(models.Model):
    created=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    owner = models.ForeignKey(User,on_delete=models.CASCADE,default=1, related_name='IncidentImages')
    image=models.ImageField(upload_to='Report/image', null=True,blank=True,default=None)
    report = models.ForeignKey(Report,default=1, related_name='ReportImages',
                            on_delete=models.CASCADE,verbose_name="Report")
    def __str__(self):
        return str(self.owner)

######################
# Report  Video CLASS
###################### 
class ReportVideo(models.Model):
    created=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    owner = models.ForeignKey(User,on_delete=models.CASCADE,default=1, related_name='IncidentVideo')
    video=models.FileField(upload_to='Report/video', null=True,blank=True,default=None)
    report = models.ForeignKey(Report,default=1, related_name='ReportVideos',
                            on_delete=models.CASCADE,verbose_name="Report")
    def __str__(self):
        return str(self.owner)

######################
# Report  Audio CLASS
###################### 
class ReportAudio(models.Model):
    created=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    owner = models.ForeignKey(User,on_delete=models.CASCADE,default=1, related_name='IncidentAudio')
    audio=models.FileField(upload_to='Report/audio', null=True,blank=True,default=None)
    report = models.ForeignKey(Report,default=1, related_name='ReportAudios',
                            on_delete=models.CASCADE,verbose_name="Report")
    def __str__(self):
        return str(self.owner)            
                        
    

######################
# Favorite CLASS
######################  
class Favorite(models.Model):
    created=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    owner = models.ForeignKey(User, related_name='Fv_owner',
                            on_delete=models.CASCADE,default=1)

    location = models.ForeignKey(WorkSection,
                                on_delete=models.CASCADE,default=1,
                                related_name='Fv_location')

    class Meta:
        unique_together = (('owner', 'location'),)                            

    def __str__(self):
        return str(self.location)

######################
# CONTATCT US CLASS
######################        
class ContactUs(models.Model):
    created=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    contact_name=models.CharField(max_length=100, default='')
    url_tel =  models.URLField(default="https://t.me/mahana_app", max_length=200)
    url_ins =  models.URLField(default="www.instagram.com/ego_official2018", max_length=200)
    url_site = models.URLField(default="https://www.danapco.com/", max_length=200)
    phone_number = PhoneNumberField(default='+989010979406')


    class Meta:
        ordering = ('-created',)
        verbose_name=_('Contact Us')
        verbose_name_plural=_('Contact Us')

    def __str__(self):
        return str(self.contact_name) 

######################
# Update CLASS
###################### 
class Update(models.Model):
    created=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    version = models.CharField(max_length=10, default='')
    url =  models.URLField(default="https://telegram.me/CyberSTM", max_length=200)
    def __str__(self):
        return str(self.version)


######################
# EMGCALL CLASS
######################
class EMGCALL(models.Model):
    created=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    emg_name=models.CharField(max_length=100, default='')
    phone_number = PhoneNumberField(default='+989010979406')

    class Meta:
        ordering = ('-created',)
        verbose_name=_('Emergency telephone number')
        verbose_name_plural=_('Emergency Telephone Numbers')
    
                     
    def __str__(self):
        return str(self.emg_name)


######################
# Logo CLASS
###################### 
class Icon(models.Model):
    created=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    Icon_name = models.CharField(max_length=10, default='')
    Icon_pic= models.ImageField(upload_to='icons', null=True,
                   blank=True,default=None,verbose_name=_('Icons'))
    def __str__(self):
        return str(self.Icon_name)