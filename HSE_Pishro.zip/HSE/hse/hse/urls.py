from django.contrib import admin
from django.contrib.auth import views 
from django.conf.urls import url, include
from rest_framework import routers
from api import apiurls,views
from django.conf.urls.static import static
from django.conf import settings
import debug_toolbar
from rest_framework.authtoken.views import obtain_auth_token  



###################################################################
import debug_toolbar
urlpatterns = [

    url(r'^jet/', include('jet.urls', 'jet')),
    #url(r'^jet_api/', include('jet_django.urls')),
    url(r'^jet/dashboard/', include('jet.dashboard.urls', 'jet-dashboard')),
    url(r'^esata/admin/', admin.site.urls),
    url(r'^hse/api/v1/', include(apiurls)),
    url(r'^__debug__/', include(debug_toolbar.urls)),
    url(r'^api-token-auth/', obtain_auth_token, name='api_token_auth'),
    url(r'^register/', views.RegistrationView.as_view(), name='register'),
    url(r'^logout/', views.Logout.as_view(),name='logout'),
    
    
]+ static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)


